package forum.UnitOfWork;

public interface IDomainObject extends Observable, Visitable {
}
