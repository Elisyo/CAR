package forum.UnitOfWork;

public interface Visitable {
	void accepter(Visiteur v);
}
