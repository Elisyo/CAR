package forum.UnitOfWork;

public interface Observateur {
	void action(IDomainObject o);
}
