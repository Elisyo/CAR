# Forum

## Accès à l'application
L'administrateur est :
Elisyo (en nom de compte)
admin (mot de passe)

Un des utilisateurs :
dylan (nom de compte)
user (mdp)

## Utilisation de l'application
Lors de l'ouverture de l'application, on arrive sur le profil du user.
A partir de là, il y a une JMenuBar qui permet de naviguer dans l'application.
On peut gérer son profil, gérer ses amis, gérer ses groupes, envoyer des messages selon les groupes (une discussion entre 2 personnes est un groupe entre 2 personnes).
L'admin a un onglet en plus, lui permettant la gestion des utilisateurs et des groupes.
Il peut les créer, les modifier, les supprimer.

Notre groupe est consititué de Florian GUILBERT (Elisyo) et Dylan DELEPLANQUE.


Notre dépôt Github : https://github.com/Elisyo/Forum