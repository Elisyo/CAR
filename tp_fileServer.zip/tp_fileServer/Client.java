package tp_fileServer;

public class Client {

}
