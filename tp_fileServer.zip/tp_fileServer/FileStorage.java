package tp_fileServer;

import java.io.File;
import java.util.List;

public class FileStorage implements FileStorageInterface{

	@Override
	public File search(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(File file, String name, List<String> tags) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String name) {
		// TODO Auto-generated method stub
		
	}
}
